public class NodoListaDoble<T> {
    T valor;
    NodoListaDoble<T> anterior;
    NodoListaDoble<T> siguiente;


}
